import * as React from 'react';
import { StyleSheet, Text, View, Image, SafeAreaView, Button, Alert } from 'react-native';

const Chat = () => {
    return(
      <SafeAreaView style = {styles.center}>
        <View>
          <Text>Chat Page</Text>
        </View>
      </SafeAreaView>
    )
  }

const styles = StyleSheet.create({
    center: {
      flex: 1,
      justifyContent: "center",
      alignItems: "center",
      textAlign: "center",
      backgroundColor: '#E2EFFC'
    },
});

export default Chat;
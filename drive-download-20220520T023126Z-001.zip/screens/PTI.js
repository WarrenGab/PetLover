import * as React from 'react';
import { StyleSheet, Text, View, Image, SafeAreaView, Button, Alert } from 'react-native';
import { createStackNavigator } from "@react-navigation/stack";

const Stack = createStackNavigator();

const PTIStack = () => {
  return (
    <Stack.Navigator>
      <Stack.Screen name="PTI Test Page 1" component={PTIStart} />
      <Stack.Screen name="PTI Test Page 2" component={PTI2} />
      <Stack.Screen name="PTI Test Page 3" component={PTI3} />
      <Stack.Screen name="PTI Test Page 4" component={PTI4} />
    </Stack.Navigator>
  );
}

const PTIStart = ({ navigation }) => {
  return (
    <SafeAreaView style={styles.container}>
      <View>
        <Text style={styles.title}>
          Ayo cari tau binatang peliharaan yang cocok untuk Anda!
        </Text>
        <View style={styles.fixToText}>
          <Button
            title="Lanjut"
            onPress={() =>
              navigation.navigate('PTI Test Page 2')
            }
          />
        </View>
      </View>
    </SafeAreaView>
  );
};

const PTI2 = ({ navigation }) => {
  return (
    <SafeAreaView style={styles.container}>
      <View>
        <Text style={styles.title}>
          Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
        </Text>
        <View style={styles.fixToText}>
          <Button
            title="1"
            onPress={() => Alert.alert('1 button pressed')}
          />
          <Button
            title="2"
            onPress={() => Alert.alert('2 button pressed')}
          />
          <Button
            title="3"
            onPress={() => Alert.alert('3 button pressed')}
          />
          <Button
            title="4"
            onPress={() => Alert.alert('4 button pressed')}
          />
          <Button
            title="5"
            onPress={() => Alert.alert('5 button pressed')}
          />
        </View>
        <View style={styles.fixToText}>
          <Button
            title="Lanjut"
            onPress={() =>
              navigation.navigate('PTI Test Page 3')
            }
          />
        </View>
      </View>
    </SafeAreaView>
  );
};

const PTI3 = ({ navigation }) => {
  return (
    <SafeAreaView style={styles.container}>
      <View>
        <Text style={styles.title}>
          Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
        </Text>
        <View>
          <Button
            title="A Lorem Ipsum"
            onPress={() => Alert.alert('A button pressed')}
          />
          <Button
            title="B Lorem Ipsum"
            onPress={() => Alert.alert('B button pressed')}
          />
          <Button
            title="C Lorem Ipsum"
            onPress={() => Alert.alert('C button pressed')}
          />
          <Button
            title="D Lorem Ipsum"
            onPress={() => Alert.alert('D button pressed')}
          />
          <Button
            title="E Lorem Ipsum"
            onPress={() => Alert.alert('E button pressed')}
          />
        </View>
        <View style={styles.fixToText}>
          <Button
            title="Lanjut"
            onPress={() =>
              navigation.navigate('PTI Test Page 4')
            }
          />
        </View>
      </View>
    </SafeAreaView>
  );
};

const PTI4 = ({ navigation }) => {
  return (
    <SafeAreaView style={styles.container}>
      <View>
        <Text style={styles.title}>
          Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
        </Text>
        <View style={styles.fixToText}>
          <Button
            title="Kembali ke home"
            onPress={() =>
              navigation.navigate('Home')
            }
          />
        </View>
      </View>
    </SafeAreaView>
  );
};



const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#E2EFFC',
    alignItems: 'center',
    justifyContent: 'space-evenly',
  },
  logo: {
    width: 200,
    height: 200,
  },
  feature: {
    width: 50,
    height: 50,
    justifyContent: 'space-evenly',
  },
  title: {
    textAlign: 'left',
    marginVertical: 8,
  },
  fixToText: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
});


export default PTIStack;
import * as React from 'react';
import { StyleSheet, Text, View, Image, SafeAreaView, Button, Alert } from 'react-native';
 

const Home = ({ navigation }) => {
    return (
      <SafeAreaView style = {styles.container}>
        <View>
          <Text>PET LOVER</Text>
        </View>
        <View style={{flexDirection: 'row'}}>
          <Image source={require("../assets/konsultasi.png")} style = {styles.feature}/>
          <Image source={require("../assets/panduan.png")} style = {styles.feature}/>
        </View>
        <View style={{flexDirection: 'row'}}>
          <Button
            title = 'Konsultasi'
            onPress={() =>
              navigation.navigate('Consultation Page')
            } 
          />
          <Button
            title = 'Panduan'
            onPress={() =>
              navigation.navigate('Guide Page')
            }
          />
        </View>
        <View style={{flexDirection: 'row'}}>
          <Image source={require("../assets/adopsi.png")} style = {styles.feature}/>
          <Image source={require("../assets/tespti.png")} style = {styles.feature}/>
        </View>
        <View style={{flexDirection: 'row'}}>
          <Button
            title = 'Adopsi'
            onPress={() =>
              navigation.navigate('Adoption Page')
            }
          />
          <Button
            title = 'Tes PTI'
            onPress={() =>
              navigation.navigate('PTI Test Start')
            }
          />
        </View>
      </SafeAreaView>
    );
  }

  const styles = StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: '#E2EFFC',
      alignItems: 'center',
      justifyContent: 'space-evenly',
    },
    logo: {
      width: 200,
      height: 200,
    },
    feature: {
      width: 50,
      height: 50,
      justifyContent: 'space-evenly',
    },
    title:{
      textAlign: 'left',
      marginVertical: 8,
    },
    fixToText: {
      flexDirection: 'row',
      justifyContent: 'space-between',
    },
  });

export default Home;